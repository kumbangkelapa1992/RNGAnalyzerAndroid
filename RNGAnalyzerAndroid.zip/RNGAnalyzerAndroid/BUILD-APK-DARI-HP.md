# Build APK langsung dari HP Android (tanpa PC)

Proyek ini menyertakan GitHub Actions untuk membangun APK di cloud.

1. Dari browser HP, masuk/daftar ke https://github.com.
2. Buat repository baru (misalnya `RNGAnalyzerAndroid`).
3. Ekstrak ZIP proyek di HP, lalu unggah seluruh isi folder proyek ke repository (pastikan folder `.github/workflows` ikut terunggah).
4. Buka tab **Actions** di repository dan pilih workflow **Build Android APK**.
5. Tekan **Run workflow**. Tunggu hingga proses selesai dengan status hijau.
6. Buka hasil run, cari bagian **Artifacts**, lalu unduh `RNGAnalyzer-debug-apk`.
7. Ekstrak file artifact ZIP, lalu buka `app-debug.apk` untuk instalasi. Jika Android meminta izin, izinkan instalasi dari sumber tersebut.

Catatan: Build debug ini untuk instalasi dan pengujian pribadi. Android mungkin menampilkan peringatan karena APK tidak didistribusikan melalui Play Store.
