package com.example.rnganalyzer;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.view.View;
import android.widget.*;
import android.text.InputType;
import java.security.SecureRandom;
import java.util.Locale;
import java.util.Arrays;

public class MainActivity extends Activity {
    private final SecureRandom random = new SecureRandom();
    private EditText spinsInput, betInput;
    private TextView resultText, statusText, detailText;
    private DistributionView chart;
    private final int[] counts = new int[6];
    private long totalSpins = 0, totalBet = 0, totalReturn = 0, wins = 0;
    // Transparent toy model: six equally likely symbols and illustrative payouts.
    private final int[] payouts = {0, 0, 2, 5, 12, 50};

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(dp(2), dp(5), dp(2), dp(5));
        return t;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(24));
        root.setBackgroundColor(Color.rgb(245,247,251));
        scroll.addView(root);

        TextView title = text("RNG ANALYZER", 26, Color.rgb(16,35,63));
        title.setTypeface(null, 1);
        root.addView(title);
        root.addView(text("Laboratorium simulasi acak • analisis statistik lokal", 13, Color.DKGRAY));

        TextView note = text("CATATAN: Model demonstrasi ini hanya menguji data acak lokal. Aplikasi tidak membaca atau mengubah RNG server slot dan tidak memprediksi jackpot.", 13, Color.rgb(130,70,0));
        note.setBackgroundColor(Color.rgb(255,242,218));
        note.setPadding(dp(12),dp(10),dp(12),dp(10));
        root.addView(note);

        root.addView(text("Jumlah putaran", 15, Color.BLACK));
        spinsInput = new EditText(this);
        spinsInput.setSingleLine(true); spinsInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        spinsInput.setText("10000");
        root.addView(spinsInput, new LinearLayout.LayoutParams(-1, dp(48)));

        root.addView(text("Taruhan per putaran (unit)", 15, Color.BLACK));
        betInput = new EditText(this);
        betInput.setSingleLine(true); betInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        betInput.setText("1");
        root.addView(betInput, new LinearLayout.LayoutParams(-1, dp(48)));

        Button run = new Button(this);
        run.setText("Jalankan simulasi");
        root.addView(run, new LinearLayout.LayoutParams(-1, dp(52)));
        run.setOnClickListener(v -> runSimulation());

        Button reset = new Button(this);
        reset.setText("Reset statistik");
        root.addView(reset, new LinearLayout.LayoutParams(-1, dp(48)));
        reset.setOnClickListener(v -> resetStats());

        statusText = text("Siap. Atur parameter lalu jalankan simulasi.", 14, Color.DKGRAY);
        root.addView(statusText);

        TextView section = text("Ringkasan hasil", 19, Color.rgb(16,35,63));
        section.setTypeface(null, 1);
        root.addView(section);
        resultText = text(summary(), 14, Color.BLACK);
        resultText.setBackgroundColor(Color.WHITE);
        resultText.setPadding(dp(12),dp(12),dp(12),dp(12));
        root.addView(resultText);

        TextView chartTitle = text("Grafik: hasil aktual vs ekspektasi", 19, Color.rgb(16,35,63));
        chartTitle.setTypeface(null, 1);
        root.addView(chartTitle);
        root.addView(text("Biru = frekuensi aktual  •  Oranye = frekuensi harapan jika peluang tiap simbol 1/6", 12, Color.DKGRAY));
        chart = new DistributionView();
        root.addView(chart, new LinearLayout.LayoutParams(-1, dp(220)));

        TextView detailTitle = text("Rincian per simbol", 19, Color.rgb(16,35,63));
        detailTitle.setTypeface(null, 1);
        root.addView(detailTitle);
        detailText = text(details(), 13, Color.BLACK);
        detailText.setBackgroundColor(Color.WHITE);
        detailText.setPadding(dp(12),dp(10),dp(12),dp(10));
        root.addView(detailText);

        root.addView(text("Model demonstrasi", 17, Color.rgb(16,35,63)));
        root.addView(text("Simbol 1: 0x taruhan   •   Simbol 2: 0x taruhan\nSimbol 3: 2x taruhan   •   Simbol 4: 5x taruhan\nSimbol 5: 12x taruhan •   Simbol 6: 50x taruhan\n\nSemua simbol memiliki peluang sama (1/6). Tabel pembayaran dan model ini hanya ilustrasi, bukan konfigurasi permainan komersial.", 13, Color.DKGRAY));
        setContentView(scroll);
    }

    private void runSimulation() {
        int n, bet;
        try {
            n = Integer.parseInt(spinsInput.getText().toString());
            bet = Integer.parseInt(betInput.getText().toString());
        } catch (Exception e) { statusText.setText("Masukkan angka yang valid."); return; }
        if (n < 1 || n > 2_000_000 || bet < 1 || bet > 1_000_000) {
            statusText.setText("Batas: 1–2.000.000 putaran dan taruhan 1–1.000.000 unit."); return;
        }

        long runBet = (long)n * bet;
        long runReturn = 0, runWins = 0;
        int[] runCounts = new int[6];
        for (int i = 0; i < n; i++) {
            int symbol = random.nextInt(6);
            runCounts[symbol]++;
            int payout = payouts[symbol];
            if (payout > 0) runWins++;
            runReturn += (long)payout * bet;
        }
        totalSpins += n; totalBet += runBet; totalReturn += runReturn; wins += runWins;
        for (int i = 0; i < 6; i++) counts[i] += runCounts[i];

        statusText.setText(String.format(Locale.US, "Selesai: %,d putaran baru.", n));
        resultText.setText(summary());
        detailText.setText(details());
        chart.invalidate();
    }

    private double chiSquare() {
        if (totalSpins == 0) return 0;
        double expected = totalSpins / 6.0, value = 0;
        for (int count : counts) { double d = count - expected; value += d * d / expected; }
        return value;
    }

    // Upper regularized incomplete gamma Q(a,x), used for the chi-square p-value (df=5).
    private double gammaQ(double a, double x) {
        if (x <= 0) return 1.0;
        if (x < a + 1.0) {
            double ap = a, sum = 1.0 / a, del = sum;
            for (int n = 1; n <= 200; n++) {
                ap += 1.0; del *= x / ap; sum += del;
                if (Math.abs(del) < Math.abs(sum) * 1e-14) break;
            }
            double p = sum * Math.exp(-x + a * Math.log(x) - logGamma(a));
            return Math.max(0.0, Math.min(1.0, 1.0 - p));
        }
        double b = x + 1.0 - a, c = 1.0 / 1e-30, d = 1.0 / b, h = d;
        for (int i = 1; i <= 200; i++) {
            double an = -i * (i - a); b += 2.0;
            d = an * d + b; if (Math.abs(d) < 1e-30) d = 1e-30;
            c = b + an / c; if (Math.abs(c) < 1e-30) c = 1e-30;
            d = 1.0 / d; double del = d * c; h *= del;
            if (Math.abs(del - 1.0) < 1e-14) break;
        }
        return Math.max(0.0, Math.min(1.0, Math.exp(-x + a * Math.log(x) - logGamma(a)) * h));
    }

    private double logGamma(double z) {
        double[] coef = {676.5203681218851, -1259.1392167224028, 771.3234287776531,
            -176.6150291621406, 12.507343278686905, -0.13857109526572012,
            9.9843695780195716e-6, 1.5056327351493116e-7};
        if (z < 0.5) return Math.log(Math.PI) - Math.log(Math.sin(Math.PI*z)) - logGamma(1-z);
        z -= 1.0; double x = 0.99999999999980993;
        for (int i=0; i<coef.length; i++) x += coef[i] / (z+i+1.0);
        double t = z + coef.length - 0.5;
        return 0.5*Math.log(2*Math.PI) + (z+0.5)*Math.log(t) - t + Math.log(x);
    }

    private String summary() {
        if (totalSpins == 0) return "Belum ada data simulasi.";
        double rtp = 100.0 * totalReturn / totalBet;
        double hit = 100.0 * wins / totalSpins;
        double chi = chiSquare(), pValue = gammaQ(2.5, chi/2.0);
        long net = totalReturn - totalBet;
        return String.format(Locale.US,
            "Total putaran: %,d\nTotal taruhan: %,d unit\nTotal pengembalian: %,d unit\nSelisih simulasi: %,d unit\nRTP teramati: %.2f%%\nFrekuensi putaran berhadiah: %.2f%%\n\nUji kesesuaian chi-kuadrat: %.3f (df=5)\np-value: %.4f\n\nUji ini membandingkan distribusi simbol dengan peluang model 1/6. p-value bukan peluang jackpot dan tidak memprediksi putaran berikutnya.",
            totalSpins, totalBet, totalReturn, net, rtp, hit, chi, pValue);
    }

    private String details() {
        if (totalSpins == 0) return "Belum ada data.";
        StringBuilder b = new StringBuilder("Simbol     Jumlah       Aktual       Harapan\n");
        for (int i=0; i<6; i++) {
            double pct = 100.0 * counts[i] / totalSpins;
            b.append(String.format(Locale.US, "S%-8d %-12s %6.2f%%     %6.2f%%\n", i+1,
                String.format(Locale.US, "%,d", counts[i]), pct, 100.0/6.0));
        }
        return b.toString();
    }

    private void resetStats() {
        Arrays.fill(counts, 0);
        totalSpins = totalBet = totalReturn = wins = 0;
        resultText.setText(summary()); detailText.setText(details());
        statusText.setText("Statistik direset."); chart.invalidate();
    }

    private class DistributionView extends View {
        private final Paint p = new Paint(3);
        DistributionView() { super(MainActivity.this); setBackgroundColor(Color.WHITE); }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float w = getWidth(), h = getHeight();
            float top = dp(30), bottom = h-dp(35), usable = bottom-top;
            p.setColor(Color.LTGRAY); p.setStrokeWidth(dp(1));
            c.drawLine(dp(12), bottom, w-dp(12), bottom, p);
            if (totalSpins == 0) {
                p.setColor(Color.GRAY); p.setTextSize(dp(13));
                c.drawText("Grafik muncul setelah simulasi", dp(16), h/2, p); return;
            }
            double expected = totalSpins / 6.0;
            double max = expected;
            for (int v : counts) max = Math.max(max, v);
            max *= 1.18;
            float slot = (w-dp(36))/6f;
            for (int i=0; i<6; i++) {
                float groupLeft = dp(18) + i*slot;
                float barW = slot*0.29f;
                float actualH = (float)(usable * counts[i] / max);
                float expectedH = (float)(usable * expected / max);
                p.setColor(Color.rgb(37,99,235));
                c.drawRoundRect(groupLeft+slot*0.12f, bottom-actualH, groupLeft+slot*0.12f+barW, bottom, dp(3), dp(3), p);
                p.setColor(Color.rgb(245,158,11));
                c.drawRoundRect(groupLeft+slot*0.53f, bottom-expectedH, groupLeft+slot*0.53f+barW, bottom, dp(3), dp(3), p);
                p.setColor(Color.DKGRAY); p.setTextSize(dp(11));
                c.drawText("S"+(i+1), groupLeft+slot*0.25f, h-dp(12), p);
            }
            p.setTextSize(dp(10)); p.setColor(Color.rgb(37,99,235));
            c.drawRect(dp(16), dp(9), dp(26), dp(19), p); c.drawText("Aktual", dp(30), dp(18), p);
            p.setColor(Color.rgb(245,158,11));
            c.drawRect(dp(86), dp(9), dp(96), dp(19), p); c.drawText("Harapan", dp(100), dp(18), p);
        }
    }
}
