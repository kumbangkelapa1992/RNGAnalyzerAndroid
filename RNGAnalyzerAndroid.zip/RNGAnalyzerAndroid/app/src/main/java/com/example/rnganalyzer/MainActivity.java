package com.example.rnganalyzer;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.text.InputType;
import java.security.SecureRandom;
import java.util.Locale;
import java.util.Arrays;

public class MainActivity extends Activity {
    private final SecureRandom random = new SecureRandom();
    private EditText spinsInput, betInput;
    private TextView resultText, statusText;
    private DistributionView chart;
    private int[] counts = new int[6];
    private long totalSpins = 0, totalBet = 0, totalReturn = 0;
    private long wins = 0;

    // Toy model only: six equally likely symbols, with a simple illustrative payout table.
    private final int[] payouts = {0, 0, 2, 5, 12, 50};

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(dp(2), dp(5), dp(2), dp(5));
        return t;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(24));
        root.setBackgroundColor(Color.rgb(245,247,251));
        scroll.addView(root);

        TextView title = text("RNG ANALYZER", 26, Color.rgb(16,35,63));
        title.setTypeface(null, 1);
        root.addView(title);
        root.addView(text("Laboratorium simulasi acak • berjalan sepenuhnya di perangkat", 13, Color.DKGRAY));

        TextView note = text("CATATAN: Ini model demonstrasi lokal, bukan alat untuk membaca atau mengubah RNG situs slot. Hasil simulasi tidak memprediksi jackpot.", 13, Color.rgb(130,70,0));
        note.setBackgroundColor(Color.rgb(255,242,218));
        note.setPadding(dp(12),dp(10),dp(12),dp(10));
        root.addView(note);

        root.addView(text("Jumlah putaran", 15, Color.BLACK));
        spinsInput = new EditText(this);
        spinsInput.setSingleLine(true); spinsInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        spinsInput.setText("10000");
        root.addView(spinsInput, new LinearLayout.LayoutParams(-1, dp(48)));

        root.addView(text("Taruhan per putaran (unit)", 15, Color.BLACK));
        betInput = new EditText(this);
        betInput.setSingleLine(true); betInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        betInput.setText("1");
        root.addView(betInput, new LinearLayout.LayoutParams(-1, dp(48)));

        Button run = new Button(this);
        run.setText("Jalankan simulasi");
        root.addView(run, new LinearLayout.LayoutParams(-1, dp(52)));
        run.setOnClickListener(v -> runSimulation());

        Button reset = new Button(this);
        reset.setText("Reset statistik");
        root.addView(reset, new LinearLayout.LayoutParams(-1, dp(48)));
        reset.setOnClickListener(v -> resetStats());

        statusText = text("Siap. Atur parameter lalu jalankan simulasi.", 14, Color.DKGRAY);
        root.addView(statusText);

        TextView section = text("Ringkasan hasil", 19, Color.rgb(16,35,63));
        section.setTypeface(null, 1);
        root.addView(section);
        resultText = text(summary(), 14, Color.BLACK);
        resultText.setBackgroundColor(Color.WHITE);
        resultText.setPadding(dp(12),dp(12),dp(12),dp(12));
        root.addView(resultText);

        root.addView(text("Distribusi simbol", 19, Color.rgb(16,35,63)));
        chart = new DistributionView();
        root.addView(chart, new LinearLayout.LayoutParams(-1, dp(190)));

        root.addView(text("Tabel model demonstrasi", 17, Color.rgb(16,35,63)));
        root.addView(text("Simbol 1: 0x taruhan   •   Simbol 2: 0x taruhan\nSimbol 3: 2x taruhan   •   Simbol 4: 5x taruhan\nSimbol 5: 12x taruhan •   Simbol 6: 50x taruhan\n\nSetiap simbol memiliki peluang 1/6 pada model sederhana ini. Model ini sengaja transparan dan bukan konfigurasi permainan komersial.", 13, Color.DKGRAY));

        setContentView(scroll);
    }

    private void runSimulation() {
        int n, bet;
        try {
            n = Integer.parseInt(spinsInput.getText().toString());
            bet = Integer.parseInt(betInput.getText().toString());
        } catch (Exception e) {
            statusText.setText("Masukkan angka yang valid."); return;
        }
        if (n < 1 || n > 2_000_000 || bet < 1 || bet > 1_000_000) {
            statusText.setText("Batas: 1–2.000.000 putaran dan taruhan 1–1.000.000 unit."); return;
        }

        long runBet = (long)n * bet;
        long runReturn = 0, runWins = 0;
        int[] runCounts = new int[6];

        for (int i = 0; i < n; i++) {
            int symbol = random.nextInt(6);
            runCounts[symbol]++;
            int payout = payouts[symbol];
            if (payout > 0) runWins++;
            runReturn += (long)payout * bet;
        }

        totalSpins += n; totalBet += runBet; totalReturn += runReturn; wins += runWins;
        for (int i = 0; i < 6; i++) counts[i] += runCounts[i];

        statusText.setText(String.format(Locale.US, "Selesai: %s putaran baru.", String.format("%,d", n)));
        resultText.setText(summary());
        chart.invalidate();
    }

    private String summary() {
        if (totalSpins == 0) return "Belum ada data simulasi.";
        double rtp = 100.0 * totalReturn / totalBet;
        double hit = 100.0 * wins / totalSpins;
        long net = totalReturn - totalBet;
        return String.format(Locale.US,
            "Total putaran: %,d\nTotal taruhan: %,d unit\nTotal pengembalian: %,d unit\nSelisih simulasi: %,d unit\nRTP teramati: %.2f%%\nFrekuensi putaran dengan hadiah: %.2f%%\n\nRTP = total pengembalian ÷ total taruhan. Angka ini hanya hasil sampel simulasi, bukan jaminan hasil di masa depan.",
            totalSpins, totalBet, totalReturn, net, rtp, hit);
    }

    private void resetStats() {
        Arrays.fill(counts, 0);
        totalSpins = totalBet = totalReturn = wins = 0;
        resultText.setText(summary());
        statusText.setText("Statistik direset.");
        chart.invalidate();
    }

    private class DistributionView extends View {
        private final Paint p = new Paint(3);
        DistributionView() { super(MainActivity.this); setBackgroundColor(Color.WHITE); }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float w = getWidth(), h = getHeight();
            p.setColor(Color.LTGRAY); p.setStrokeWidth(dp(1));
            c.drawLine(dp(12), h-dp(28), w-dp(12), h-dp(28), p);
            int max = 1; for (int v : counts) max = Math.max(max, v);
            float slot = (w-dp(36))/6f;
            for (int i=0;i<6;i++) {
                float bh = (h-dp(65)) * counts[i] / max;
                float left = dp(18) + i*slot + slot*0.2f;
                float right = left + slot*0.6f;
                p.setColor(Color.rgb(37,99,235));
                c.drawRoundRect(left, h-dp(29)-bh, right, h-dp(29), dp(4), dp(4), p);
                p.setColor(Color.DKGRAY); p.setTextSize(dp(11));
                c.drawText("S"+(i+1), left, h-dp(10), p);
                p.setTextSize(dp(10));
                c.drawText(String.valueOf(counts[i]), left, Math.max(dp(14), h-dp(34)-bh), p);
            }
            if (totalSpins == 0) {
                p.setColor(Color.GRAY); p.setTextSize(dp(13));
                c.drawText("Grafik muncul setelah simulasi", dp(16), h/2, p);
            }
        }
    }
}
