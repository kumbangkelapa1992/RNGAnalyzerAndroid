# RNG Analyzer Android — versi grafik analisis

Aplikasi Android native untuk simulasi RNG lokal dan pembelajaran statistik.

## Fitur
- Simulasi 1 sampai 2.000.000 putaran per batch menggunakan `SecureRandom`.
- Grafik batang berdampingan: frekuensi simbol aktual vs frekuensi harapan (model seragam 1/6).
- Rincian jumlah dan persentase tiap simbol.
- Uji kesesuaian chi-kuadrat (5 derajat bebas) dan p-value untuk membandingkan distribusi sampel dengan model seragam.
- Ringkasan taruhan, pengembalian, RTP sampel, frekuensi hadiah, dan selisih.
- Reset statistik.

## Build melalui GitHub Actions
Proyek ini dapat dibangun sebagai APK debug melalui workflow di `.github/workflows/build-apk.yml`. Untuk menjalankan workflow, push perubahan ke branch `main` atau pilih Actions → Build Android APK → Run workflow.

## Batasan dan interpretasi
Ini model demonstrasi enam simbol yang sama-sama berpeluang 1/6 dengan tabel pembayaran ilustratif. Aplikasi tidak mengakses situs/aplikasi pihak ketiga, tidak membaca atau mengubah RNG server, dan tidak memprediksi jackpot. RTP adalah hasil sampel model, bukan jaminan. Uji chi-kuadrat hanya mengukur seberapa jauh frekuensi sampel menyimpang dari peluang model yang ditentukan; hasilnya tidak mengungkap pola atau hasil masa depan.
