# RNG Analyzer Android

Aplikasi Android native sederhana untuk simulasi RNG dan analisis distribusi hasil secara lokal.

## Membuka proyek
1. Ekstrak ZIP.
2. Buka folder `RNGAnalyzerAndroid` melalui Android Studio.
3. Tunggu Gradle Sync. Gunakan JDK 17 dan Android SDK 35.
4. Jalankan ke emulator atau perangkat Android (aktifkan Developer options dan USB debugging jika memakai kabel).

## Fitur
- Simulasi 1 sampai 2.000.000 putaran per batch.
- Generator angka acak `SecureRandom` pada perangkat.
- Statistik jumlah putaran, taruhan, pengembalian, selisih, RTP teramati, dan frekuensi hadiah.
- Grafik distribusi enam simbol.
- Reset statistik.

## Batasan
Model ini hanya demonstrasi statistik dengan enam simbol yang peluangnya sama (1/6) dan tabel pembayaran ilustratif. Ini bukan replika permainan komersial, tidak mengakses situs/aplikasi pihak ketiga, tidak membaca atau mengubah RNG server, dan tidak dapat memprediksi jackpot. RTP sampel dapat berubah-ubah dan tidak menjamin hasil berikutnya.

## Build APK
Di Android Studio pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**. APK debug biasanya dibuat di `app/build/outputs/apk/debug/`.
